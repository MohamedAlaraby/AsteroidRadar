package com.udacity.asteroidradar.repository

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.LiveData

import androidx.lifecycle.Transformations.map
import com.udacity.asteroidradar.api.AsteroidApi
import com.udacity.asteroidradar.domain.Asteroid
import com.udacity.asteroidradar.utils.Constants
import com.udacity.asteroidradar.utils.parseAsteroidsJsonResult
import com.udacity.asteroidradar.database.AsteroidDB
import com.udacity.asteroidradar.database.asDatabaseModel
import com.udacity.asteroidradar.database.asDomainModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

//the repository is responsible for fetching the data from network and storing them in the database
class Repository(private val database: AsteroidDB) {

    val asteroid_list: LiveData<List<Asteroid>> =
        map(database.asteroidDao.getAllAsteroids()){
            it.asDomainModel()
        }
    @RequiresApi(Build.VERSION_CODES.O)
    private val startDate = LocalDateTime.now()
    @RequiresApi(Build.VERSION_CODES.O)
    private val endDate =   LocalDateTime.now().plusDays(7)
    @RequiresApi(Build.VERSION_CODES.O)
    val todayAsteroids: LiveData<List<Asteroid>> =
        map(database.asteroidDao.getTodayAsteroids(startDate.format(DateTimeFormatter.ISO_DATE))) {
            it.asDomainModel()
        }

    @RequiresApi(Build.VERSION_CODES.O)
    val weekAsteroids: LiveData<List<Asteroid>> = map(
            database.asteroidDao.getNextSevenDaysAsteroids(
                startDate.format(DateTimeFormatter.ISO_DATE),
                endDate.format(DateTimeFormatter.ISO_DATE)
            )) {it.asDomainModel()}



suspend fun refreshAsteroids(){
     withContext(Dispatchers.IO){
         try{
             val responseAsString=AsteroidApi.retrofitService.getAsteroids(Constants.API_KEY)
             val resultList= parseAsteroidsJsonResult(JSONObject(responseAsString))
             database.asteroidDao.insertAll(*resultList.asDatabaseModel())
             Log.d("Refresh Asteroids", "Success")
         } catch (err: Exception) {

             Log.e("Failed: AsteroidRepFile", err.message.toString())
         }
     }
}


}